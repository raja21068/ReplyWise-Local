# Browser Agent Channels

## WhatsApp

Uses `whatsapp-web.js`. First run prints a QR code in terminal. Scan from WhatsApp Linked Devices.

## Telegram

Uses `web.telegram.org/a`. First run needs phone/OTP login in the browser window.

## Instagram

Uses `instagram.com/direct/inbox`. First run needs normal login and any 2FA challenge.

## Slack

Uses `SLACK_WORKSPACE_URL`, defaulting to `https://app.slack.com`. If you have a specific workspace deep link, set it in `.env`.

## LINE

Uses `LINE_WEB_URL`, defaulting to `https://web.line.me/`. LINE web availability varies by account/region.

## Microsoft Teams

Uses `TEAMS_WEB_URL`, defaulting to `https://teams.microsoft.com/v2/`. This web app is heavy; allocate more RAM.

## Google Chat

Uses `GOOGLE_CHAT_WEB_URL`, defaulting to Gmail Chat. Google login/MFA may be required.

## WeChat

Uses `WECHAT_WEB_URL`, defaulting to WeChat Web. Some accounts cannot use WeChat Web.
