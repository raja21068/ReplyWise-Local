# Architecture

RelationshipOS has two processes:

1. **Orchestrator**: Express server, dashboard, local file store, memory, suggestions, outgoing queue.
2. **Browser agents**: one process can launch multiple channel agents. Each agent owns a persistent browser session.

```text
Messaging Web Client
   ↓ DOM / websocket / internal response watcher
Browser Agent
   ↓ POST /api/ingest/:channel
Orchestrator
   ↓ memory + recent messages
AI suggestion engine
   ↓
Dashboard approval
   ↓
Outgoing queue
   ↓ polling by channel
Browser Agent sends via UI
```

The uploaded agent design used a universal `BaseAgent` that defines login URL, login checks, message watcher, and `sendMessageViaUI`. This package keeps that pattern and adds the missing server/db/AI pieces around it.

## Zero API key boundary

This build does not use official messaging channel APIs. It uses logged-in browser sessions and local dashboard approval. Optional Ollama is local only.

## Session persistence

Each channel stores cookies/localStorage/IndexedDB under:

```text
data/sessions/<channel>/
```

Mount that folder as a persistent volume in Docker/OCI.


## Free-cost operating mode

The browser agents do not need screenshots to read messages. Incoming text is captured through DOM observers, WebSocket events, or network-response parsing depending on the platform. Screenshots are disabled by default because they increase storage, CPU, and review cost.

Default cost-saving settings:

```env
FREE_COST_MODE=true
AI_PROVIDER=local
SCREENSHOT_ON_ERROR=false
ENABLE_LIVE_SCREENSHOTS=false
BRIDGE_POLL_MS=7000
HEALTH_CHECK_INTERVAL=60
```

Use screenshots only for short debugging sessions, then disable them again.
