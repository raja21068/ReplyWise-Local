# Safety and Boundaries

This build is human-in-the-loop. It never sends an AI suggestion automatically.

Hard rules in code:

- `ALLOW_AUTOSEND=true` is rejected by `assertHumanApproval()`.
- The dashboard approval endpoint is the only path that creates outgoing queue items.
- Unsafe phrases are filtered from suggestions.
- Browser agents only send items already approved and queued by the orchestrator.

Operational rules:

- Use a test account or secondary number.
- Respect platform terms and user privacy.
- Do not use this for spam, harassment, deception, impersonation, or mass outreach.
- Keep data local unless you intentionally deploy it.
