# Free-Cost Update Notes

This build removes screenshot dependency from the normal runtime path.

## Defaults

- `FREE_COST_MODE=true`
- `AI_PROVIDER=local`
- `SCREENSHOT_ON_ERROR=false`
- `ENABLE_LIVE_SCREENSHOTS=false`
- `ENABLED_AGENTS=whatsapp`
- `BRIDGE_POLL_MS=7000`
- `HEALTH_CHECK_INTERVAL=60`

## How messages are read

Agents read message text using DOM observers, WebSocket listeners, and network-response parsing where supported. They do not read screenshots/OCR.

## When to enable screenshots

Only for short debugging sessions when a browser selector/login flow is broken:

```env
SCREENSHOT_ON_ERROR=true
```

Turn it back off after debugging.
