# RelationshipOS Browser Agent — Zero Messaging API Keys

This is the corrected build for the architecture you described: **not official API keys**, not bot-token adapters, and not fake-only CLI bridges. It uses a local orchestrator plus browser-session agents that log in through the normal web clients.

## What changed in this version

- Browser-agent architecture based on the uploaded `BaseAgent` contract.
- WhatsApp uses `whatsapp-web.js` with QR login and persistent LocalAuth.
- Telegram, Instagram, Slack use Playwright browser sessions.
- Added browser-agent shells for LINE, Microsoft Teams, Google Chat, and WeChat.
- Local dashboard still has sandbox ingest for testing without opening browsers.
- No WhatsApp Cloud API token, no Telegram bot token, no LINE token, no Slack app token, no Teams bot token, no Google Chat API key.
- Local rule-based AI by default; optional Ollama local model only.
- Manual approval is required before any outgoing message is queued.
- Free-cost mode is default: no screenshots, no OCR, no cloud AI, no official messaging APIs.

## Important risk note

Browser automation of consumer messaging web clients may violate platform terms and can break when UIs change. This package does **not** include stealth or anti-detection patches. Use a test account/number, keep output slow, and only send messages you personally approve.


## Free-cost mode

This build is optimized to run as cheaply as possible:

- `AI_PROVIDER=local` by default, so no paid AI API is required.
- `FREE_COST_MODE=true` by default.
- `SCREENSHOT_ON_ERROR=false` and `ENABLE_LIVE_SCREENSHOTS=false` by default.
- Agents read messages from DOM/WebSocket/network events, not screenshots.
- The re-auth page uses status text and visible browser login; it does not require image reading.
- Default polling is slower (`BRIDGE_POLL_MS=7000`) and health checks are slower (`HEALTH_CHECK_INTERVAL=60`) to reduce CPU.
- Default enabled agent is only WhatsApp; add more channels one by one after testing.

Only enable screenshots temporarily when a selector is broken:

```env
SCREENSHOT_ON_ERROR=true
```

Turn it back off after debugging.

## Quick start

```bash
cp .env.example .env
npm install
npm run reset
npm run seed
npm run dev
```

Open:

```text
http://localhost:3000
```

Test the pipeline from the dashboard with **Sandbox Test**, or run:

```bash
npm run smoke
```

## Start browser agents

Start the orchestrator first:

```bash
npm run dev
```

Then open a second terminal:

```bash
npm run agents
```

Default `.env.example` starts only WhatsApp in free-cost mode. To test more channels, edit `ENABLED_AGENTS` manually, for example `ENABLED_AGENTS=whatsapp,telegram`.

Or one channel at a time:

```bash
npm run agent:whatsapp
npm run agent:telegram
npm run agent:instagram
npm run agent:slack
npm run agent:line
npm run agent:teams
npm run agent:google-chat
npm run agent:wechat
```

For first login, set this in `.env` so you can see the browser:

```env
BROWSER_HEADLESS=false
```

Sessions are saved under:

```text
data/sessions/<channel>/
```

## Flow

```text
Web client/browser agent
        ↓ POST /api/ingest/:channel
Orchestrator
        ↓ contact memory + recent messages
Local AI / Ollama
        ↓
Dashboard shows 3 suggestions
        ↓ manual approval only
Outgoing queue
        ↓ browser agent polls /api/bridge/pending-outgoing?channel=...
Browser agent opens chat, types, sends
```

## Channel status

| Channel | Mode | Notes |
|---|---|---|
| WhatsApp | `whatsapp-web.js` | QR login, persistent session. |
| Telegram | Playwright Web | Phone/OTP login once, session saved. |
| Instagram | Playwright Web | DM inbox, network + DOM detection. UI may change often. |
| Slack | Playwright Web | Workspace login, WebSocket + DOM detection. |
| LINE | Playwright Web | Best-effort DOM adapter; configure `LINE_WEB_URL` if needed. |
| Teams | Playwright Web | Heavy web client; more RAM recommended. |
| Google Chat | Playwright Web | Google login/MFA; configure URL if needed. |
| WeChat | Playwright Web | Availability depends on account/region support for WeChat Web. |

## Docker

```bash
docker compose up --build
```

For agents:

```bash
ENABLED_AGENTS=whatsapp,telegram BROWSER_HEADLESS=false docker compose up --build
```

## Project structure

```text
src/server.js                 Orchestrator + dashboard
src/db/index.js               Local JSON file store
src/ai/                       Local rule engine + optional Ollama
src/safety/guardrails.js      Safety filters and manual approval check
src/bridge/base-agent.js      Universal Playwright browser agent
src/bridge/*-agent.js         Per-channel browser agents
src/bridge/agent-manager.js   Launches/restarts enabled agents
```

## No official messaging API credentials

The `.env.example` intentionally contains no official messaging API token fields. The only optional external AI setting is Ollama, which is local and does not require an API key.
