require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const morgan = require('morgan');
const db = require('./db');
const ai = require('./ai');
const { assertHumanApproval, cleanSuggestionText } = require('./safety/guardrails');

const app = express();
const port = Number(process.env.PORT || 3000);

function boolEnv(name, defaultValue = false) {
  const raw = process.env[name];
  if (raw === undefined || raw === null || raw === '') return defaultValue;
  return ['1', 'true', 'yes', 'on'].includes(String(raw).toLowerCase());
}

function screenshotsEnabled() {
  return boolEnv('SCREENSHOT_ON_ERROR', false) || boolEnv('ENABLE_LIVE_SCREENSHOTS', false);
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(morgan('dev'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// ═══════════════════════════════════════════════════════════
// Dashboard
// ═══════════════════════════════════════════════════════════

app.get('/', async (req, res, next) => {
  try {
    const [contacts, pendingSuggestions, outgoingQueue, agentStatuses] = await Promise.all([
      db.listContacts(),
      db.listPendingSuggestions(),
      db.listOutgoingQueue(),
      db.getAgentStatuses(),
    ]);
    res.send(renderDashboard({
      contacts,
      pendingSuggestions,
      outgoingQueue,
      agentStatuses,
      env: {
        aiProvider: process.env.AI_PROVIDER || 'local',
        enabledAgents: process.env.ENABLED_AGENTS || 'whatsapp',
      },
    }));
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════════════════════════════════════
// Ingest API (browser agents POST here)
// ═══════════════════════════════════════════════════════════

app.post('/api/ingest/:channel', async (req, res, next) => {
  try {
    const result = await processIncomingMessage({
      channel: req.params.channel,
      externalContactId: req.body.from || req.body.externalContactId || req.body.contactId,
      displayName: req.body.displayName,
      body: req.body.body,
      timestamp: req.body.timestamp,
      metadata: { source: `${req.params.channel}-browser-agent`, raw: req.body },
    });
    res.json({ ok: true, suggestionId: result.suggestion.id });
  } catch (err) {
    next(err);
  }
});

// Legacy WhatsApp ingest route (backward compatibility)
app.post('/api/ingest/whatsapp', async (req, res, next) => {
  try {
    const result = await processIncomingMessage({
      channel: 'whatsapp',
      externalContactId: req.body.from || req.body.whatsappId || req.body.externalContactId,
      displayName: req.body.displayName,
      body: req.body.body,
      timestamp: req.body.timestamp,
      metadata: { source: 'whatsapp-browser-agent', raw: req.body },
    });
    res.json({ ok: true, suggestionId: result.suggestion.id });
  } catch (err) {
    next(err);
  }
});

// Sandbox incoming (for testing without agents)
app.post('/api/sandbox/:channel/incoming', async (req, res, next) => {
  try {
    const channel = db.normalizeChannel(req.params.channel);
    const result = await processIncomingMessage({
      channel,
      externalContactId: req.body.externalContactId || req.body.contactId,
      displayName: req.body.displayName,
      body: req.body.body,
      metadata: { source: `${channel}_sandbox_ui` },
    });
    if (req.accepts('html')) return res.redirect('/');
    res.json({ ok: true, suggestionId: result.suggestion.id });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════════════════════════════════════
// Suggestion approval
// ═══════════════════════════════════════════════════════════

app.post('/api/suggestions/:id/approve', async (req, res, next) => {
  try {
    assertHumanApproval();
    const chosenText = cleanSuggestionText(req.body.chosenText);
    if (!chosenText) throw new Error('chosenText is required');
    await db.approveSuggestion({ suggestionId: req.params.id, chosenText, bridge: req.body.bridge });
    if (req.accepts('html')) return res.redirect('/');
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

app.post('/api/suggestions/:id/skip', async (req, res, next) => {
  try {
    await db.skipSuggestion(req.params.id);
    if (req.accepts('html')) return res.redirect('/');
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════════════════════════════════════
// Bridge outgoing queue (agents poll this)
// ═══════════════════════════════════════════════════════════

app.get('/api/bridge/pending-outgoing', async (req, res, next) => {
  try {
    const channel = req.query.channel || null;
    const rows = await db.getPendingOutgoing({ channel, limit: Number(req.query.limit || 10) });
    res.json({ ok: true, outgoing: rows });
  } catch (err) {
    next(err);
  }
});

app.post('/api/bridge/outgoing/:id/sent', async (req, res, next) => {
  try {
    await db.markOutgoingSent(req.params.id);
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

app.post('/api/bridge/outgoing/:id/failed', async (req, res, next) => {
  try {
    await db.markOutgoingFailed(req.params.id, req.body.error || 'Unknown error');
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════════════════════════════════════
// Agent status & re-auth
// ═══════════════════════════════════════════════════════════

app.post('/api/agents/:channel/status', async (req, res, next) => {
  try {
    await db.updateAgentStatus(req.params.channel, req.body.status, req.body.errorLog);
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

app.get('/api/agents/status', async (req, res, next) => {
  try {
    const statuses = await db.getAgentStatuses();
    res.json({ ok: true, agents: statuses });
  } catch (err) {
    next(err);
  }
});

// Re-auth page: no screenshot required by default; login is done in visible browser/terminal
app.get('/reauth/:channel', (req, res) => {
  const channel = db.normalizeChannel(req.params.channel);
  res.send(renderReauthPage(channel));
});

app.get('/api/screenshots/:channel/latest', (req, res) => {
  if (!screenshotsEnabled()) {
    return res.status(404).send('Screenshots are disabled. Set SCREENSHOT_ON_ERROR=true only when debugging.');
  }
  const fs = require('fs');
  const path = require('path');
  const channel = db.normalizeChannel(req.params.channel);
  const dir = path.resolve(process.env.SCREENSHOT_DIR || './data/screenshots');
  if (!fs.existsSync(dir)) return res.status(404).send('No screenshots yet');
  const files = fs.readdirSync(dir)
    .filter(f => f.startsWith(`${channel}-`) && f.endsWith('.png'))
    .map(f => ({ f, t: fs.statSync(path.join(dir, f)).mtimeMs }))
    .sort((a, b) => b.t - a.t);
  if (!files.length) return res.status(404).send('No screenshots yet');
  res.type('png').send(fs.readFileSync(path.join(dir, files[0].f)));
});

// ═══════════════════════════════════════════════════════════
// Profile refresh
// ═══════════════════════════════════════════════════════════

app.post('/api/profile-refresh/run', async (req, res, next) => {
  try {
    const refreshed = await runProfileRefreshJob();
    if (req.accepts('html')) return res.redirect('/');
    res.json({ ok: true, refreshed });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════════════════════════════════════
// Core pipeline
// ═══════════════════════════════════════════════════════════

async function processIncomingMessage({ channel, externalContactId, displayName, body, timestamp, metadata }) {
  const normalizedChannel = db.normalizeChannel(channel);
  if (!body || !String(body).trim()) throw new Error('body is required');
  if (!externalContactId) throw new Error('externalContactId is required');

  const contact = await db.upsertContact({
    channel: normalizedChannel,
    externalContactId: String(externalContactId).trim(),
    displayName,
  });

  const incoming = await db.insertMessage({
    contactId: contact.id,
    direction: 'incoming',
    body: String(body).trim(),
    timestamp: parseTimestamp(timestamp),
    metadata: { channel: normalizedChannel, ...metadata },
  });

  const recentMessages = await db.getRecentMessages(contact.id, Number(process.env.MAX_RECENT_MESSAGES || 20));
  const userPersona = await db.getSetting('user_persona');
  const result = await ai.generateSuggestions({ contact, recentMessages, incomingMessage: incoming, userPersona });

  const suggestion = await db.createSuggestion({
    contactId: contact.id,
    incomingMessageId: incoming.id,
    result,
  });

  return { contact, incoming, suggestion, result };
}

function parseTimestamp(value) {
  if (!value) return new Date().toISOString();
  if (typeof value === 'number' || /^\d+$/.test(String(value))) {
    const n = Number(value);
    return new Date(n > 100000000000 ? n : n * 1000).toISOString();
  }
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? new Date().toISOString() : parsed.toISOString();
}

async function runProfileRefreshJob() {
  const min = Number(process.env.PROFILE_REFRESH_MIN_NEW_MESSAGES || 20);
  const max = Number(process.env.PROFILE_REFRESH_MAX_MESSAGES || 200);
  const contacts = await db.contactsNeedingRefresh(min);
  const refreshed = [];
  for (const contact of contacts) {
    const messages = await db.getMessagesSinceLastProfile(contact.id, max);
    if (!messages.length) continue;
    const result = await ai.summarizeProfile({ contact, messages });
    await db.updateContactProfile({
      contactId: contact.id,
      summary: result.summary,
      preferredLanguage: result.preferredLanguage,
      emojiStyle: result.emojiStyle,
      conversationStage: result.conversationStage,
    });
    refreshed.push({ contactId: contact.id, channel: contact.channel, ...result });
  }
  return refreshed;
}

// ═══════════════════════════════════════════════════════════
// HTML Renderers (minimal, functional dashboard)
// ═══════════════════════════════════════════════════════════

function renderDashboard({ contacts, pendingSuggestions, outgoingQueue, agentStatuses, env }) {
  const agentRows = (agentStatuses || []).map((a) => {
    const icon = a.status === 'active' ? '🟢' : a.status === 'login_required' ? '🟡' : '🔴';
    const reauthLink = a.status === 'login_required'
      ? ` <a href="/reauth/${a.channel}" style="color:#4f8df7">[Re-auth]</a>` : '';
    return `<tr><td>${icon} ${a.channel}</td><td>${a.status}${reauthLink}</td><td>${a.errorLog || '—'}</td></tr>`;
  }).join('');

  const suggestionCards = (pendingSuggestions || []).map((s) => {
    const options = typeof s.optionsJson === 'string' ? JSON.parse(s.optionsJson) : (s.optionsJson || []);
    const optionButtons = (Array.isArray(options) ? options : []).map((opt) => `
      <div style="margin:6px 0;padding:8px;border:1px solid #ddd;border-radius:6px;background:#fafafa">
        <strong>${opt.tone || 'reply'}</strong>: ${opt.text || ''}
        <form method="POST" action="/api/suggestions/${s.id}/approve" style="display:inline;margin-left:8px">
          <input type="hidden" name="chosenText" value="${(opt.text || '').replace(/"/g, '&quot;')}">
          <button type="submit" style="padding:2px 10px;cursor:pointer">Send this</button>
        </form>
      </div>`).join('');

    const incomingBody = s.incomingMessage?.body || s.incoming_body || '';
    const contactName = s.contact?.displayName || s.display_name || 'Unknown';
    const ch = s.contact?.channel || s.channel || '';

    return `
      <div style="border:1px solid #ccc;border-radius:8px;padding:12px;margin:10px 0;background:#fff">
        <div><strong>${ch.toUpperCase()}</strong> · ${contactName}</div>
        <div style="color:#555;margin:4px 0">Their message: "${incomingBody}"</div>
        ${optionButtons}
        <div style="margin-top:6px">
          <form method="POST" action="/api/suggestions/${s.id}/approve" style="display:inline">
            <input name="chosenText" placeholder="Custom reply..." style="width:250px;padding:4px">
            <button type="submit" style="padding:4px 10px;cursor:pointer">Send Custom</button>
          </form>
          <form method="POST" action="/api/suggestions/${s.id}/skip" style="display:inline;margin-left:8px">
            <button type="submit" style="padding:4px 10px;cursor:pointer;color:#c33">Skip</button>
          </form>
        </div>
      </div>`;
  }).join('') || '<p style="color:#888">No pending suggestions</p>';

  const contactRows = (contacts || []).slice(0, 20).map((c) => `
    <tr>
      <td>${c.channel}</td>
      <td>${c.displayName || c.display_name || c.externalContactId || c.external_contact_id}</td>
      <td>${c.conversationStage || c.conversation_stage || 'initial'}</td>
      <td>${c.message_count || c._count?.messages || 0}</td>
      <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${c.last_message || c.messages?.[0]?.body || '—'}</td>
    </tr>`).join('');

  return `<!DOCTYPE html>
<html><head><title>RelationshipOS</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  *{box-sizing:border-box} body{font-family:system-ui,sans-serif;max-width:960px;margin:0 auto;padding:16px;background:#f5f5f0}
  h1{margin:0 0 4px} h2{margin:20px 0 8px;border-bottom:2px solid #333;padding-bottom:4px}
  table{border-collapse:collapse;width:100%} th,td{text-align:left;padding:6px 10px;border-bottom:1px solid #ddd}
  th{background:#eee} .badge{display:inline-block;padding:2px 8px;border-radius:4px;font-size:12px;background:#e0e0e0}
  .sandbox-form{margin:8px 0;padding:10px;border:1px solid #ddd;border-radius:6px;background:#fff}
  .sandbox-form input,.sandbox-form textarea{padding:4px 8px;margin:2px 4px}
</style>
</head><body>
  <h1>RelationshipOS</h1>
  <p>Browser agent mode · AI: ${env.aiProvider} · Agents: ${env.enabledAgents}</p>

  <h2>Agent Status</h2>
  <table><tr><th>Channel</th><th>Status</th><th>Error</th></tr>${agentRows || '<tr><td colspan=3>No agents reporting</td></tr>'}</table>

  <h2>Pending Suggestions</h2>
  ${suggestionCards}

  <h2>Contacts (${(contacts || []).length})</h2>
  <table><tr><th>Channel</th><th>Name</th><th>Stage</th><th>Msgs</th><th>Last</th></tr>${contactRows}</table>

  <h2>Sandbox Test</h2>
  <div class="sandbox-form">
    <form method="POST" action="/api/sandbox/whatsapp/incoming">
      <strong>Simulate incoming:</strong>
      <select name="channel" onchange="this.form.action='/api/sandbox/'+this.value+'/incoming'">
        <option>whatsapp</option><option>telegram</option><option>instagram</option><option>slack</option><option>line</option><option>teams</option><option>google-chat</option><option>wechat</option>
      </select>
      <input name="externalContactId" placeholder="contact_id" required>
      <input name="displayName" placeholder="Display Name">
      <input name="body" placeholder="Message text" required style="width:250px">
      <button type="submit">Send</button>
    </form>
  </div>

  <h2>Manual Profile Refresh</h2>
  <form method="POST" action="/api/profile-refresh/run"><button type="submit">Run Profile Refresh</button></form>

  <script>setTimeout(()=>location.reload(),15000)</script>
</body></html>`;
}

function renderReauthPage(channel) {
  return `<!DOCTYPE html>
<html><head><title>Re-auth: ${channel}</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  body{font-family:system-ui,sans-serif;max-width:600px;margin:40px auto;padding:16px;text-align:center}
  h1{margin-bottom:4px} .status{padding:12px;border-radius:8px;margin:16px 0;font-size:18px}
  .active{background:#d4edda;color:#155724} .login{background:#fff3cd;color:#856404} .error{background:#f8d7da;color:#721c24}
  img{max-width:100%;border:1px solid #ccc;border-radius:8px;margin-top:16px}
  .instructions{text-align:left;background:#f8f8f4;padding:16px;border-radius:8px;margin:16px 0}
</style></head><body>
  <h1>Re-authenticate: ${channel}</h1>
  <div id="status" class="status login">Checking status...</div>

  <div class="instructions">
    <h3>How to log in:</h3>
    ${channel === 'whatsapp' ? '<p>1. Open WhatsApp on your phone<br>2. Tap Settings → Linked Devices → Link a Device<br>3. Scan the QR code shown by the agent (check the terminal output)</p>' : ''}
    ${channel === 'telegram' ? '<p>1. The browser is open at web.telegram.org<br>2. Enter your phone number and the OTP code<br>3. Session will persist after login</p>' : ''}
    ${channel === 'instagram' ? '<p>1. The browser is open at instagram.com<br>2. Enter your username and password<br>3. Complete any 2FA challenges<br>4. Session cookies will persist</p>' : ''}
    ${channel === 'slack' ? '<p>1. The browser is open at app.slack.com<br>2. Log in with your email and password<br>3. Select your workspace<br>4. Session will persist</p>' : ''}
    ${channel === 'line' ? '<p>1. The browser is open at LINE Web / configured LINE_WEB_URL<br>2. Complete QR or account login<br>3. Session will persist after login</p>' : ''}
    ${channel === 'teams' ? '<p>1. The browser is open at teams.microsoft.com<br>2. Complete Microsoft login / MFA<br>3. Session will persist after login</p>' : ''}
    ${channel === 'google-chat' ? '<p>1. The browser is open at Google Chat<br>2. Complete Google login / MFA<br>3. Session will persist after login</p>' : ''}
    ${channel === 'wechat' ? '<p>1. The browser is open at WeChat Web<br>2. Scan QR if your account supports WeChat Web<br>3. Some accounts/regions may not be supported</p>' : ''}
    ${screenshotsEnabled() ? `<p>Debug screenshot: <a href="/api/screenshots/${channel}/latest" target="_blank">open latest screenshot</a></p>` : '<p><strong>Screenshots:</strong> disabled for free-cost mode. Use the visible browser or terminal QR/OTP prompts.</p>'}
    <p><strong>Tip:</strong> Keep BROWSER_HEADLESS=false while logging in so no screenshot reading is needed.</p>
  </div>

  <p><a href="/">← Back to Dashboard</a></p>

  <script>
    async function checkStatus() {
      try {
        const res = await fetch('/api/agents/status');
        const data = await res.json();
        const agent = (data.agents || []).find(a => a.channel === '${channel}');
        const el = document.getElementById('status');
        if (!agent) {
          el.className = 'status error';
          el.textContent = 'Agent not found — is it running?';
        } else if (agent.status === 'active') {
          el.className = 'status active';
          el.textContent = '✓ Agent is active and connected!';
        } else if (agent.status === 'login_required') {
          el.className = 'status login';
          el.textContent = '⚠ Login required — follow the instructions below';
        } else {
          el.className = 'status error';
          el.textContent = 'Status: ' + agent.status + (agent.errorLog ? ' — ' + agent.errorLog : '');
        }
      } catch { /* ignore */ }
    }
    checkStatus();
    setInterval(checkStatus, 5000);
  </script>
</body></html>`;
}

// ═══════════════════════════════════════════════════════════
// Error handler & startup
// ═══════════════════════════════════════════════════════════

app.use((err, req, res, _next) => {
  console.error(err);
  if (req.accepts('html')) {
    return res.status(400).send(`<h1>Error</h1><pre>${String(err.message || err)}</pre><p><a href="/">Back</a></p>`);
  }
  res.status(400).json({ ok: false, error: err.message || String(err) });
});

app.listen(port, async () => {
  // Ensure default settings exist
  const existing = await db.getSetting('user_persona');
  if (!existing) {
    await db.setSetting(
      'user_persona',
      'I am calm, respectful, playful when appropriate, and prefer natural short replies. I do not pressure people.'
    );
  }

  console.log(`\nRelationshipOS orchestrator running at http://localhost:${port}`);
  console.log(`AI: ${process.env.AI_PROVIDER || 'local'} · Agents: ${process.env.ENABLED_AGENTS || 'whatsapp'}`);
  console.log('Zero messaging API keys. Human approval required for every outgoing message.\n');
});

module.exports = { processIncomingMessage, runProfileRefreshJob };
