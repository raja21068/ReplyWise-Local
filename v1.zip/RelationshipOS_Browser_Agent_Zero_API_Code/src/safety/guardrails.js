function containsUnsafeText(text) {
  const lower = String(text || '').toLowerCase();
  const blocked = [
    'send me pics',
    'prove you like me',
    'if you cared',
    'you owe me',
    'i will keep messaging',
    'don\'t tell anyone',
    'secret from everyone'
  ];
  return blocked.some((phrase) => lower.includes(phrase));
}

function cleanSuggestionText(text) {
  return String(text || '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 600);
}

function filterOptions(options) {
  const safe = [];
  for (const option of options || []) {
    const text = cleanSuggestionText(option.text);
    if (!text) continue;
    if (containsUnsafeText(text)) continue;
    safe.push({
      tone: String(option.tone || 'casual').slice(0, 60),
      text,
      rationale: String(option.rationale || 'Fits the current conversation.').slice(0, 300),
      score: Number(option.score || 75),
      risk: option.risk || 'low'
    });
  }
  while (safe.length < 3) {
    safe.push({
      tone: ['casual', 'warm', 'simple'][safe.length] || 'casual',
      text: ['Haha fair 😂', 'That sounds interesting, tell me more.', 'I get you, makes sense.'][safe.length] || 'Makes sense.',
      rationale: 'Safe fallback option.',
      score: 70,
      risk: 'low'
    });
  }
  return safe.slice(0, 3);
}

function assertHumanApproval() {
  if (String(process.env.ALLOW_AUTOSEND || 'false').toLowerCase() === 'true') {
    throw new Error('Autonomous sending is disabled in this build. Keep ALLOW_AUTOSEND=false.');
  }
}

module.exports = {
  containsUnsafeText,
  cleanSuggestionText,
  filterOptions,
  assertHumanApproval
};
