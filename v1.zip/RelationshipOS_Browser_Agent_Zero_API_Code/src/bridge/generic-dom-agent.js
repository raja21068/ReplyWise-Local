const BaseAgent = require('./base-agent');

/**
 * GenericDomAgent
 * Best-effort browser-session adapter for heavy web apps where selectors change often.
 * It does NOT use official messaging APIs or bot tokens. It relies on a logged-in
 * browser session, DOM observation, and manual approval from the orchestrator.
 */
class GenericDomAgent extends BaseAgent {
  constructor({ channel, name, loginUrl, loginSelectors = [], inboxSelectors = [], searchShortcut = null }) {
    super({ channel, name });
    this.loginUrl = loginUrl;
    this.loginSelectors = loginSelectors;
    this.inboxSelectors = inboxSelectors;
    this.searchShortcut = searchShortcut;
  }

  getLoginUrl() {
    return this.loginUrl;
  }

  async isLoggedIn(page) {
    try {
      const url = page.url().toLowerCase();
      if (/login|signin|auth|passport/.test(url)) return false;
      for (const selector of this.loginSelectors) {
        const found = await page.$(selector);
        if (found) return true;
      }
      await page.waitForTimeout(2500);
      for (const selector of this.loginSelectors) {
        const found = await page.$(selector);
        if (found) return true;
      }
      return !/login|signin|auth|passport/.test(page.url().toLowerCase());
    } catch {
      return false;
    }
  }

  async handleLogin(page) {
    this.log('Manual login required.');
    this.log('===========================================================');
    this.log(`  Open: ${this.orchestratorUrl}/reauth/${this.channel}`);
    this.log(`  Browser URL: ${this.loginUrl}`);
    this.log('  Complete QR / OTP / username login in the browser.');
    this.log('  Session will persist in SESSION_DIR after login.');
    this.log('===========================================================');

    const combined = this.loginSelectors.join(', ');
    if (combined) {
      await page.waitForSelector(combined, { timeout: 300000 });
    } else {
      await page.waitForTimeout(300000);
    }
    this.log('Login appears complete.');
  }

  async installMessageWatcher(page) {
    await page.evaluate(({ channel }) => {
      const seen = new Set();
      const messageSelectors = [
        '[data-message-id]',
        '[data-qa="message_container"]',
        '[role="row"]',
        '[class*="message"]',
        '[class*="Message"]',
        '[class*="msg"]',
      ];

      function cleanText(value) {
        return String(value || '').replace(/\s+/g, ' ').trim();
      }

      function currentChatName() {
        const selectors = [
          '[role="main"] h1',
          '[role="main"] h2',
          'header h1',
          'header h2',
          '[data-qa="channel_name"]',
          '[class*="title"]',
          '[class*="Title"]',
        ];
        for (const s of selectors) {
          const el = document.querySelector(s);
          const text = cleanText(el && el.textContent);
          if (text) return text.slice(0, 80);
        }
        return 'Unknown';
      }

      function currentChatId(name) {
        const urlKey = location.pathname.split('/').filter(Boolean).slice(-2).join('_') || location.hash.replace(/[^a-zA-Z0-9_-]/g, '_');
        return `${channel}_${urlKey || name}`;
      }

      function processElement(el) {
        if (!(el instanceof HTMLElement)) return;
        const text = cleanText(el.innerText || el.textContent);
        if (!text || text.length < 1 || text.length > 2000) return;
        if (/^send$|^search$|^new message$/i.test(text)) return;

        const key = el.getAttribute('data-message-id') || el.id || `${text.slice(0, 100)}_${location.href}`;
        if (seen.has(key)) return;
        seen.add(key);
        if (seen.size > 5000) {
          const arr = Array.from(seen).slice(-2500);
          seen.clear();
          arr.forEach(x => seen.add(x));
        }

        const name = currentChatName();
        window.__rosOnMessage({
          from: currentChatId(name),
          displayName: name,
          body: text,
          timestamp: new Date().toISOString(),
        });
      }

      const observer = new MutationObserver((mutations) => {
        for (const m of mutations) {
          for (const node of m.addedNodes) {
            if (!(node instanceof HTMLElement)) continue;
            if (messageSelectors.some(s => node.matches?.(s))) processElement(node);
            for (const s of messageSelectors) {
              node.querySelectorAll?.(s).forEach(processElement);
            }
          }
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
      console.log(`[ROS] Generic DOM observer installed for ${channel}`);
    }, { channel: this.channel });

    this.log('Message watcher installed (generic DOM observer)');
  }

  async sendMessageViaUI(page, { externalContactId, displayName, body }) {
    const target = displayName || externalContactId;

    // Try direct URL first for agents that store a URL-like ID.
    if (/^https?:\/\//.test(String(externalContactId || ''))) {
      await page.goto(externalContactId, { waitUntil: 'domcontentloaded', timeout: 60000 });
      await this.randomDelay(1000, 2000);
    } else {
      await this.openSearchAndSelect(page, target);
    }

    await this.focusComposer(page);
    await this.humanTypeIntoFocused(page, body);
    await page.keyboard.press('Enter');
    await this.randomDelay(800, 1500);
  }

  async openSearchAndSelect(page, target) {
    if (!target) return;
    if (this.searchShortcut === 'ctrl-k') {
      await page.keyboard.down(process.platform === 'darwin' ? 'Meta' : 'Control');
      await page.keyboard.press('k');
      await page.keyboard.up(process.platform === 'darwin' ? 'Meta' : 'Control');
    } else {
      const selectors = [
        'input[type="search"]',
        'input[placeholder*="Search" i]',
        'input[aria-label*="Search" i]',
        '[role="searchbox"]',
      ];
      let clicked = false;
      for (const s of selectors) {
        const el = await page.$(s);
        if (el) { await el.click(); clicked = true; break; }
      }
      if (!clicked) {
        await page.keyboard.down(process.platform === 'darwin' ? 'Meta' : 'Control');
        await page.keyboard.press('k');
        await page.keyboard.up(process.platform === 'darwin' ? 'Meta' : 'Control');
      }
    }
    await this.randomDelay(500, 1000);
    await page.keyboard.type(String(target), { delay: this.randomInt(this.typingDelayMin, this.typingDelayMax) });
    await this.randomDelay(1000, 1800);
    await page.keyboard.press('Enter');
    await this.randomDelay(1500, 2500);
  }

  async focusComposer(page) {
    const selectors = [
      '[contenteditable="true"][role="textbox"]',
      '[role="textbox"]',
      'div[contenteditable="true"]',
      'textarea',
      'input[type="text"]',
    ];
    for (const s of selectors) {
      const elements = await page.$$(s);
      if (elements.length) {
        await elements[elements.length - 1].click();
        return;
      }
    }
    throw new Error(`${this.name}: could not find message composer`);
  }
}

module.exports = GenericDomAgent;
