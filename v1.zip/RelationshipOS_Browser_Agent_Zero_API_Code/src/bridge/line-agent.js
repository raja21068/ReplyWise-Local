const GenericDomAgent = require('./generic-dom-agent');

class LineAgent extends GenericDomAgent {
  constructor() {
    super({
      channel: 'line',
      name: 'LINE',
      loginUrl: process.env.LINE_WEB_URL || 'https://web.line.me/',
      loginSelectors: ['[role="main"]', '[contenteditable="true"]', 'input[type="search"]'],
      inboxSelectors: ['[role="main"]'],
    });
  }
}

module.exports = LineAgent;
