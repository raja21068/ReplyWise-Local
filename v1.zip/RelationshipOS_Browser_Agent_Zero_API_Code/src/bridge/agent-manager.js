/**
 * Agent Manager — launches, monitors, and auto-restarts all enabled browser agents.
 *
 * Usage:
 *   ENABLED_AGENTS=whatsapp,telegram,instagram,slack,line,teams,google-chat,wechat node src/bridge/agent-manager.js
 *
 * Each agent runs in-process but isolated. If one crashes, the manager
 * restarts it without affecting the others.
 */

require('dotenv').config();

const WhatsAppAgent = require('./whatsapp-agent');
const TelegramAgent = require('./telegram-agent');
const InstagramAgent = require('./instagram-agent');
const SlackAgent = require('./slack-agent');
const LineAgent = require('./line-agent');
const TeamsAgent = require('./teams-agent');
const GoogleChatAgent = require('./google-chat-agent');
const WeChatAgent = require('./wechat-agent');

// ── Agent registry ──────────────────────────────────────

const AGENT_CLASSES = {
  whatsapp: WhatsAppAgent,
  telegram: TelegramAgent,
  instagram: InstagramAgent,
  slack: SlackAgent,
  line: LineAgent,
  teams: TeamsAgent,
  'google-chat': GoogleChatAgent,
  googlechat: GoogleChatAgent,
  wechat: WeChatAgent,
};

class AgentManager {
  constructor() {
    this.agents = new Map(); // channel -> { instance, restarts, lastError }
    this.maxRestarts = 5;
    this.restartDelayMs = 10000;
    this.running = false;
  }

  async start() {
    this.running = true;
    const enabled = (process.env.ENABLED_AGENTS || 'whatsapp')
      .split(',')
      .map((s) => s.trim().toLowerCase())
      .filter(Boolean);

    console.log(`\n╔══════════════════════════════════════════════════════════╗`);
    console.log(`║  RelationshipOS Agent Manager                           ║`);
    console.log(`║  Browser-agent mode — zero messaging API keys           ║`);
    console.log(`╠══════════════════════════════════════════════════════════╣`);
    console.log(`║  Enabled agents: ${enabled.join(', ').padEnd(39)}║`);
    console.log(`║  Orchestrator:   ${(process.env.APP_BASE_URL || 'http://localhost:3000').padEnd(39)}║`);
    console.log(`║  AI provider:    ${(process.env.AI_PROVIDER || 'local').padEnd(39)}║`);
    console.log(`║  Headless:       ${(process.env.BROWSER_HEADLESS !== 'false' ? 'yes' : 'no').padEnd(39)}║`);
    console.log(`╚══════════════════════════════════════════════════════════╝\n`);

    for (const channel of enabled) {
      const AgentClass = AGENT_CLASSES[channel];
      if (!AgentClass) {
        console.warn(`[manager] Unknown agent: ${channel} — skipping`);
        continue;
      }
      await this.launchAgent(channel, AgentClass);
    }

    // Print status every 60 seconds
    this.statusInterval = setInterval(() => this.printStatus(), 60000);
  }

  async launchAgent(channel, AgentClass) {
    const record = this.agents.get(channel) || { instance: null, restarts: 0, lastError: null };
    this.agents.set(channel, record);

    const agent = new AgentClass();
    record.instance = agent;

    // Listen for events
    agent.on('login_required', () => {
      console.log(`\n  ⚠  [${channel}] Login required!`);
      console.log(`     Open: ${process.env.APP_BASE_URL || 'http://localhost:3000'}/reauth/${channel}\n`);
    });

    agent.on('disconnected', (reason) => {
      console.log(`\n  ✗  [${channel}] Disconnected: ${reason}\n`);
      if (this.running && record.restarts < this.maxRestarts) {
        this.scheduleRestart(channel, AgentClass);
      }
    });

    try {
      console.log(`[manager] Launching ${channel} agent...`);
      await agent.start();
      console.log(`[manager] ✓ ${channel} agent is running`);
    } catch (err) {
      record.lastError = err.message;
      console.error(`[manager] ✗ ${channel} agent failed: ${err.message}`);
      if (this.running && record.restarts < this.maxRestarts) {
        this.scheduleRestart(channel, AgentClass);
      }
    }
  }

  scheduleRestart(channel, AgentClass) {
    const record = this.agents.get(channel);
    if (!record) return;
    record.restarts += 1;
    const delay = this.restartDelayMs * record.restarts; // Progressive backoff

    console.log(`[manager] Scheduling restart #${record.restarts} for ${channel} in ${delay / 1000}s...`);

    setTimeout(async () => {
      if (!this.running) return;
      try {
        if (record.instance) {
          await record.instance.stop().catch(() => {});
        }
      } catch {
        // ignore
      }
      await this.launchAgent(channel, AgentClass);
    }, delay);
  }

  printStatus() {
    console.log('\n── Agent Status ────────────────────────────────────');
    for (const [channel, record] of this.agents) {
      const agent = record.instance;
      const status = agent?.healthy ? '✓ active' : '✗ down';
      const restarts = record.restarts > 0 ? ` (restarts: ${record.restarts})` : '';
      const error = record.lastError ? ` — ${record.lastError.slice(0, 50)}` : '';
      console.log(`  ${channel.padEnd(15)} ${status}${restarts}${error}`);
    }
    console.log('────────────────────────────────────────────────────\n');
  }

  async stop() {
    this.running = false;
    clearInterval(this.statusInterval);
    console.log('[manager] Stopping all agents...');

    const promises = [];
    for (const [channel, record] of this.agents) {
      if (record.instance) {
        promises.push(
          record.instance.stop().catch((err) => {
            console.error(`[manager] Error stopping ${channel}: ${err.message}`);
          })
        );
      }
    }
    await Promise.all(promises);
    console.log('[manager] All agents stopped');
  }

  getStatuses() {
    const result = {};
    for (const [channel, record] of this.agents) {
      result[channel] = {
        healthy: record.instance?.healthy || false,
        restarts: record.restarts,
        lastError: record.lastError,
        running: record.instance?.running || false,
      };
    }
    return result;
  }

  getAgent(channel) {
    return this.agents.get(channel)?.instance || null;
  }
}

// ── Standalone launch ────────────────────────────────────
if (require.main === module) {
  const manager = new AgentManager();
  manager.start().catch((err) => {
    console.error('Agent manager failed:', err);
    process.exit(1);
  });

  const shutdown = async () => {
    await manager.stop();
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

module.exports = AgentManager;
