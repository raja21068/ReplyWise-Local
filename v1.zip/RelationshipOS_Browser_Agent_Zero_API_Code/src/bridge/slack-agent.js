/**
 * Slack Agent — Playwright automation of app.slack.com
 *
 * Login: Email + password or magic link (session persists via cookies).
 * Message detection: WebSocket frame interception (Slack uses WS for real-time).
 * Sending: Finds channel/DM, types in message composer, presses Enter.
 */

const BaseAgent = require('./base-agent');

class SlackAgent extends BaseAgent {
  constructor() {
    super({ channel: 'slack', name: 'Slack' });
    this.workspaceUrl = process.env.SLACK_WORKSPACE_URL || 'https://app.slack.com';
    this.seenTimestamps = new Set();
  }

  getLoginUrl() {
    return this.workspaceUrl;
  }

  async isLoggedIn(page) {
    try {
      const url = page.url();
      if (url.includes('/signin') || url.includes('/sign-in')) return false;

      // Slack shows the workspace when logged in — look for the sidebar
      const sidebar = await page.$(
        '[class*="sidebar"], [data-qa="channel_sidebar"], [class*="ChannelSidebar"]'
      );
      if (sidebar) return true;

      await page.waitForTimeout(3000);
      return !page.url().includes('/signin');
    } catch {
      return false;
    }
  }

  async handleLogin(page) {
    this.log('Waiting for manual Slack login...');
    this.log('===========================================================');
    this.log('  Slack requires manual login the first time.');
    this.log(`  Open: ${this.orchestratorUrl}/reauth/slack`);
    this.log('  Log in with your email and password.');
    this.log('  Session will persist after first login.');
    this.log('===========================================================');

    try {
      await page.waitForSelector(
        '[class*="sidebar"], [data-qa="channel_sidebar"]',
        { timeout: 300000 }
      );
      this.log('Login successful!');
    } catch {
      throw new Error('Slack login timed out');
    }
  }

  async installMessageWatcher(page) {
    // Strategy 1: WebSocket interception (Slack's primary real-time transport)
    page.on('websocket', (ws) => {
      this.log(`WebSocket connected: ${ws.url().slice(0, 60)}`);

      ws.on('framereceived', ({ payload }) => {
        this.parseSlackWebSocketFrame(payload);
      });
    });

    // Strategy 2: DOM observer for direct messages
    await page.evaluate(() => {
      const seen = new Set();

      const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          for (const node of mutation.addedNodes) {
            if (!(node instanceof HTMLElement)) continue;

            // Look for message kit items
            const msgs = node.querySelectorAll?.('[data-qa="message_container"], [class*="c-message_kit"]') || [];
            const candidates = node.matches?.('[data-qa="message_container"]') ? [node, ...msgs] : [...msgs];

            for (const el of candidates) {
              const ts = el.getAttribute('data-item-key') || el.id;
              if (!ts || seen.has(ts)) continue;
              seen.add(ts);

              // Get message text
              const textEl = el.querySelector('[data-qa="message-text"], [class*="message_body"]');
              const text = textEl?.textContent?.trim();
              if (!text) continue;

              // Get sender
              const senderEl = el.querySelector('[data-qa="message_sender_name"], [class*="sender"]');
              const senderName = senderEl?.textContent?.trim() || 'Unknown';

              // Get channel from URL
              const match = window.location.pathname.match(/\/client\/[^/]+\/([A-Z0-9]+)/);
              const channelId = match ? match[1] : 'unknown';

              window.__rosOnMessage({
                from: `slack_${channelId}_${senderName}`,
                displayName: senderName,
                body: text,
                timestamp: new Date().toISOString(),
              });
            }
          }
        }
      });

      observer.observe(document.body, { childList: true, subtree: true });
      console.log('[ROS] Slack DOM observer installed');
    });

    this.log('Message watcher installed (WebSocket + DOM fallback)');
  }

  parseSlackWebSocketFrame(payload) {
    if (typeof payload !== 'string') return;
    try {
      const data = JSON.parse(payload);

      // Slack WS messages have type: 'message'
      if (data.type === 'message' && data.subtype !== 'bot_message' && !data.bot_id) {
        // Skip if we're the sender
        if (data.subtype === 'message_changed') return;

        const ts = data.ts || data.event_ts;
        if (this.seenTimestamps.has(ts)) return;
        this.seenTimestamps.add(ts);

        // Keep the set manageable
        if (this.seenTimestamps.size > 5000) {
          const arr = [...this.seenTimestamps];
          this.seenTimestamps = new Set(arr.slice(-2500));
        }

        this.onIncomingMessage({
          from: `slack_${data.channel || 'unknown'}_${data.user || 'unknown'}`,
          displayName: data.user || data.username || 'Unknown',
          body: data.text || '',
        });
      }
    } catch {
      // Not a JSON text frame — ignore
    }
  }

  async sendMessageViaUI(page, { externalContactId, displayName, body }) {
    // externalContactId format: slack_C12345_U67890
    const parts = externalContactId.replace(/^slack_/, '').split('_');
    const channelId = parts[0] || '';
    const searchName = displayName || channelId;

    // Step 1: Use Cmd+K / Ctrl+K to open quick switcher
    await page.keyboard.down('Control');
    await page.keyboard.press('k');
    await page.keyboard.up('Control');
    await this.randomDelay(500, 1000);

    // Step 2: Type the channel/person name
    const switcherInput = await page.$('[data-qa="focusable_search_input"] input, [class*="QuickSwitcher"] input');
    if (switcherInput) {
      await this.humanTypeIntoFocused(page, searchName);
      await this.randomDelay(1000, 2000);
      await page.keyboard.press('Enter');
      await this.randomDelay(500, 1000);
    }

    // Step 3: Find and focus the message composer
    const composer = await page.$(
      '[data-qa="message_input"] [role="textbox"], [class*="ql-editor"], [contenteditable="true"][data-qa]'
    );
    if (!composer) {
      throw new Error(`Could not find Slack message composer for ${searchName}`);
    }

    await composer.click();
    await this.randomDelay(200, 500);
    await this.humanTypeIntoFocused(page, body);
    await this.randomDelay(300, 600);

    // Step 4: Send
    await page.keyboard.press('Enter');
    this.log(`Message sent to ${searchName}`);
    await this.randomDelay(500, 1500);
  }
}

// ── Standalone launch ────────────────────────────────────
if (require.main === module) {
  require('dotenv').config();
  const agent = new SlackAgent();
  agent.start().catch((err) => {
    console.error('Slack agent failed:', err);
    process.exit(1);
  });
  process.on('SIGINT', () => agent.stop().then(() => process.exit(0)));
  process.on('SIGTERM', () => agent.stop().then(() => process.exit(0)));
}

module.exports = SlackAgent;
