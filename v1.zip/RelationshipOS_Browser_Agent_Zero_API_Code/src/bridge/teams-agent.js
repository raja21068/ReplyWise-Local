const GenericDomAgent = require('./generic-dom-agent');

class TeamsAgent extends GenericDomAgent {
  constructor() {
    super({
      channel: 'teams',
      name: 'Microsoft Teams',
      loginUrl: process.env.TEAMS_WEB_URL || 'https://teams.microsoft.com/v2/',
      loginSelectors: ['[data-tid="app-layout-area--main"]', '[role="main"]', '[contenteditable="true"]'],
      inboxSelectors: ['[role="main"]'],
      searchShortcut: 'ctrl-k',
    });
  }

  async installMessageWatcher(page) {
    page.on('websocket', (ws) => {
      this.log(`WebSocket connected: ${ws.url().slice(0, 60)}...`);
      ws.on('framereceived', ({ payload }) => this.parseFrame(payload));
    });
    await super.installMessageWatcher(page);
  }

  parseFrame(payload) {
    if (typeof payload !== 'string' || !payload.includes('message')) return;
    try {
      const data = JSON.parse(payload);
      const body = data?.text || data?.message?.text || data?.resource?.content;
      if (!body) return;
      this.onIncomingMessage({
        from: `teams_${data?.conversationId || data?.threadId || 'unknown'}`,
        displayName: data?.from?.name || data?.senderName || 'Teams',
        body,
      });
    } catch {}
  }
}

module.exports = TeamsAgent;
