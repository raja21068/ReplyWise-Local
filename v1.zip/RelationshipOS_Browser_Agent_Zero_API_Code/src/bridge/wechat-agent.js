const GenericDomAgent = require('./generic-dom-agent');

class WeChatAgent extends GenericDomAgent {
  constructor() {
    super({
      channel: 'wechat',
      name: 'WeChat',
      loginUrl: process.env.WECHAT_WEB_URL || 'https://web.wechat.com/',
      loginSelectors: ['.chat', '.main', '[contenteditable="true"]', '[ng-repeat*="message"]'],
      inboxSelectors: ['.chat', '.main'],
    });
  }

  async handleLogin(page) {
    this.log('WeChat Web normally uses QR login and may be unavailable for some accounts/regions.');
    await super.handleLogin(page);
  }
}

module.exports = WeChatAgent;
