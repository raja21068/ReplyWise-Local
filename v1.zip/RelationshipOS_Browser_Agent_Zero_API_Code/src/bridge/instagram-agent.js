/**
 * Instagram Agent — Playwright automation of instagram.com DMs
 *
 * Login: Username + password with saved cookies (session persists via Playwright context).
 * Message detection: Network request interception on /api/v1/direct_v2/ endpoints.
 * Sending: Navigates to the DM thread, types into message input, sends.
 *
 * NOTE: Instagram is aggressive with automation detection. Mitigations:
 *   - Real user-agent, locale, timezone
 *   - Human typing delays (30-120ms per char)
 *   - Random action delays (500-2000ms between actions)
 *   - No rapid-fire actions
 *   - Session persistence (no repeated logins)
 */

const BaseAgent = require('./base-agent');

class InstagramAgent extends BaseAgent {
  constructor() {
    super({ channel: 'instagram', name: 'Instagram' });
    this.knownThreads = new Map(); // threadId -> last seen itemId
  }

  getLoginUrl() {
    return 'https://www.instagram.com/direct/inbox/';
  }

  async isLoggedIn(page) {
    try {
      // If we're redirected to login page, not logged in
      const url = page.url();
      if (url.includes('/accounts/login')) return false;

      // Check for inbox elements
      const inboxEl = await page.$(
        '[class*="direct"] [class*="inbox"], [aria-label="Inbox"], [role="main"] [class*="thread"]'
      );
      if (inboxEl) return true;

      // Check for the navigation bar (logged-in indicator)
      const navBar = await page.$('nav [role="link"][href="/"], nav [aria-label="Home"]');
      if (navBar) return true;

      await page.waitForTimeout(3000);
      return !page.url().includes('/accounts/login');
    } catch {
      return false;
    }
  }

  async handleLogin(page) {
    this.log('Waiting for manual login...');
    this.log('===========================================================');
    this.log('  Instagram requires manual login the first time.');
    this.log(`  Open: ${this.orchestratorUrl}/reauth/instagram`);
    this.log('  Or if headless=false, log in through the browser window.');
    this.log('  Session cookies will persist for future launches.');
    this.log('===========================================================');

    // If we're on the login page, wait for redirect to inbox
    if (page.url().includes('/accounts/login')) {
      try {
        await page.waitForURL('**/direct/inbox/**', { timeout: 300000 });
        this.log('Login successful!');
      } catch {
        throw new Error('Login timed out after 5 minutes');
      }
    }

    // Handle "Turn on Notifications" popup if it appears
    await this.dismissPopups(page);
  }

  async dismissPopups(page) {
    try {
      const notNow = await page.$('button:has-text("Not Now"), [role="button"]:has-text("Not Now")');
      if (notNow) {
        await notNow.click();
        await this.randomDelay(500, 1000);
      }
    } catch {
      // No popup — fine
    }
  }

  async installMessageWatcher(page) {
    // Strategy 1: Intercept Instagram's internal API responses
    page.on('response', async (response) => {
      try {
        const url = response.url();

        // Catch inbox polling and thread updates
        if (
          url.includes('/api/v1/direct_v2/inbox/') ||
          url.includes('/api/v1/direct_v2/threads/') ||
          url.includes('/api/graphql')
        ) {
          const contentType = response.headers()['content-type'] || '';
          if (!contentType.includes('json')) return;

          const body = await response.json().catch(() => null);
          if (!body) return;

          this.processInboxResponse(body);
        }
      } catch {
        // Not every response is relevant — ignore
      }
    });

    // Strategy 2: DOM observer for message bubbles
    await page.evaluate(() => {
      const seen = new Set();

      const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          for (const node of mutation.addedNodes) {
            if (!(node instanceof HTMLElement)) continue;

            // Look for message containers
            const msgs = node.querySelectorAll?.('[class*="message"], [role="row"]') || [];
            const candidates = node.matches?.('[class*="message"], [role="row"]') ? [node, ...msgs] : [...msgs];

            for (const el of candidates) {
              // Skip own messages (usually right-aligned or has specific class)
              const isOwn = el.classList?.toString().includes('self') ||
                            el.querySelector?.('[class*="self"]') ||
                            el.closest?.('[class*="outgoing"]');
              if (isOwn) continue;

              const textEl = el.querySelector('[dir="auto"], [class*="text"]');
              const text = textEl?.textContent?.trim();
              if (!text || text.length < 1) continue;

              const msgKey = `${text.slice(0, 30)}_${Date.now()}`;
              if (seen.has(msgKey)) continue;
              seen.add(msgKey);

              // Get thread title from header
              const header = document.querySelector(
                '[class*="thread"] [class*="header"] [class*="title"], [class*="direct-thread"] a[role="link"]'
              );
              const senderName = header?.textContent?.trim() || 'Unknown';

              // Extract thread ID from URL
              const match = window.location.pathname.match(/\/direct\/t\/(\d+)/);
              const threadId = match ? match[1] : senderName;

              window.__rosOnMessage({
                from: `ig_${threadId}`,
                displayName: senderName,
                body: text,
                timestamp: new Date().toISOString(),
              });
            }
          }
        }
      });

      observer.observe(document.body, { childList: true, subtree: true });
      console.log('[ROS] Instagram message observer installed');
    });

    this.log('Message watcher installed (API intercept + DOM fallback)');
  }

  processInboxResponse(data) {
    try {
      // Instagram inbox response structure
      const threads = data?.inbox?.threads || data?.threads || [];
      for (const thread of threads) {
        const items = thread.items || [];
        const threadId = thread.thread_id;
        const participants = thread.users || [];

        // Find the last seen item for this thread
        const lastSeen = this.knownThreads.get(threadId);

        for (const item of items) {
          // Skip own messages
          if (item.user_id?.toString() === thread.viewer_id?.toString()) continue;

          // Skip already-seen items
          if (lastSeen && item.item_id <= lastSeen) continue;

          // Extract text
          let text = null;
          if (item.item_type === 'text') {
            text = item.text;
          } else if (item.item_type === 'link') {
            text = item.link?.text || item.text;
          } else if (item.item_type === 'reel_share') {
            text = item.reel_share?.text || '[Shared a reel]';
          } else if (item.item_type === 'media_share') {
            text = '[Shared a post]';
          }

          if (!text) continue;

          // Find sender name
          const sender = participants.find((u) => u.pk?.toString() === item.user_id?.toString());
          const displayName = sender?.full_name || sender?.username || `user_${item.user_id}`;

          this.onIncomingMessage({
            from: `ig_${threadId}`,
            displayName,
            body: text,
          });
        }

        // Update last seen
        if (items.length > 0) {
          this.knownThreads.set(threadId, items[0].item_id);
        }
      }
    } catch (err) {
      // Parsing errors are expected — Instagram changes response format
      this.log(`Inbox parse warning: ${err.message}`);
    }
  }

  async sendMessageViaUI(page, { externalContactId, displayName, body }) {
    const threadId = externalContactId.replace(/^ig_/, '');
    const searchName = displayName || threadId;

    // Step 1: Navigate to the DM thread
    // Try direct URL first
    try {
      await page.goto(`https://www.instagram.com/direct/t/${threadId}/`, {
        waitUntil: 'domcontentloaded',
        timeout: 15000,
      });
      await this.randomDelay(1500, 3000);
      await this.dismissPopups(page);
    } catch {
      this.log(`Direct thread URL failed, trying search for ${searchName}`);
    }

    // Step 2: Find the message input
    const msgInput = await page.$(
      'textarea[placeholder*="Message"], [role="textbox"][aria-label*="Message"], [contenteditable="true"][role="textbox"]'
    );

    if (!msgInput) {
      // Fallback: try the search approach
      this.log('Message input not found, trying to search for conversation');

      // Click "New Message" or use search
      const searchBtn = await page.$(
        '[aria-label="New message"], [class*="NewMessage"], svg[aria-label*="New"]'
      );
      if (searchBtn) {
        await searchBtn.click();
        await this.randomDelay(500, 1000);

        const searchInput = await page.$('input[name="queryBox"], input[placeholder*="Search"]');
        if (searchInput) {
          await this.humanType(page, 'input[name="queryBox"], input[placeholder*="Search"]', searchName);
          await this.randomDelay(1500, 2500);
          await page.keyboard.press('Enter');
          await this.randomDelay(1000, 2000);
        }
      }

      // Try finding input again
      const retryInput = await page.$(
        'textarea[placeholder*="Message"], [role="textbox"], [contenteditable="true"]'
      );
      if (!retryInput) {
        throw new Error(`Could not find message input for ${searchName}`);
      }
    }

    // Step 3: Type and send
    const finalInput = await page.$(
      'textarea[placeholder*="Message"], [role="textbox"][aria-label*="Message"], [contenteditable="true"][role="textbox"]'
    );
    await finalInput.click();
    await this.randomDelay(200, 500);

    // Instagram uses textarea or contenteditable — handle both
    const tagName = await finalInput.evaluate((el) => el.tagName.toLowerCase());
    if (tagName === 'textarea') {
      await finalInput.fill('');
      await this.humanTypeIntoFocused(page, body);
    } else {
      // contenteditable
      await page.keyboard.down('Control');
      await page.keyboard.press('a');
      await page.keyboard.up('Control');
      await page.keyboard.press('Backspace');
      await this.humanTypeIntoFocused(page, body);
    }

    await this.randomDelay(300, 800);

    // Step 4: Click send button or press Enter
    const sendBtn = await page.$('button[type="submit"]:has-text("Send"), [role="button"]:has-text("Send")');
    if (sendBtn) {
      await sendBtn.click();
    } else {
      await page.keyboard.press('Enter');
    }

    this.log(`Message sent to ${searchName}`);
    await this.randomDelay(1000, 2000);
  }
}

// ── Standalone launch ────────────────────────────────────
if (require.main === module) {
  require('dotenv').config();
  const agent = new InstagramAgent();
  agent.start().catch((err) => {
    console.error('Instagram agent failed:', err);
    process.exit(1);
  });
  process.on('SIGINT', () => agent.stop().then(() => process.exit(0)));
  process.on('SIGTERM', () => agent.stop().then(() => process.exit(0)));
}

module.exports = InstagramAgent;
