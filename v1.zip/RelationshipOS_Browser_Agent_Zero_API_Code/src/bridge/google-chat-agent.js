const GenericDomAgent = require('./generic-dom-agent');

class GoogleChatAgent extends GenericDomAgent {
  constructor() {
    super({
      channel: 'google-chat',
      name: 'Google Chat',
      loginUrl: process.env.GOOGLE_CHAT_WEB_URL || 'https://mail.google.com/chat/u/0/',
      loginSelectors: ['[role="main"]', '[aria-label*="Chat" i]', '[contenteditable="true"]'],
      inboxSelectors: ['[role="main"]'],
    });
  }
}

module.exports = GoogleChatAgent;
