require('dotenv').config();
const db = require('./index');

async function seed() {
  console.log('Seeding RelationshipOS browser-agent store...');

  await db.setSetting(
    'user_persona',
    'I am calm, respectful, playful when appropriate, and prefer natural short replies. I use mixed English/Roman Urdu sometimes, but I never pressure people.'
  );

  const contacts = [
    { channel: 'whatsapp', externalContactId: '923001234567@c.us', displayName: 'Ayesha WhatsApp' },
    { channel: 'telegram', externalContactId: 'tg_ayesha_1001', displayName: 'Ayesha Telegram' },
    { channel: 'instagram', externalContactId: 'ig_12345678', displayName: 'Sara Instagram' },
    { channel: 'slack', externalContactId: 'slack_C12345_U67890', displayName: 'Slack DM Test' },
    { channel: 'line', externalContactId: 'line_ayesha', displayName: 'LINE Test' },
    { channel: 'teams', externalContactId: 'teams_ayesha', displayName: 'Teams Test' },
    { channel: 'google-chat', externalContactId: 'gchat_ayesha', displayName: 'Google Chat Test' },
    { channel: 'wechat', externalContactId: 'wxid_ayesha', displayName: 'WeChat Test' },
  ];

  for (const c of contacts) {
    await db.upsertContact(c);
    console.log(`  ✓ ${c.channel}: ${c.displayName}`);
  }

  const ayesha = await db.getContactByExternalId('whatsapp', '923001234567@c.us');
  if (ayesha) {
    const messages = [
      { direction: 'incoming', body: 'Hey, how are you?', offset: -7200 },
      { direction: 'outgoing', body: 'Good alhamdulillah, just got back from work. You?', offset: -7000 },
      { direction: 'incoming', body: 'Same haha. Bohot thak gayi hun exam prep se', offset: -6800 },
      { direction: 'outgoing', body: 'Oof exam season is brutal. Kab hai?', offset: -6600 },
      { direction: 'incoming', body: 'Next week 😩 pray for me', offset: -6400 },
      { direction: 'outgoing', body: 'InshaAllah you will ace it. You always do 💪', offset: -6200 },
      { direction: 'incoming', body: "Aww thanks 🥺 so what's your weekend plan?", offset: -3600 },
    ];
    for (const m of messages) {
      await db.insertMessage({
        contactId: ayesha.id,
        direction: m.direction,
        body: m.body,
        timestamp: new Date(Date.now() + m.offset * 1000).toISOString(),
      });
    }
    console.log(`  ✓ Added ${messages.length} sample messages for Ayesha`);
  }

  console.log('Seed complete.');
}

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
