const fs = require('fs');
const path = require('path');
const file = path.resolve(process.env.STORE_FILE || path.join(process.env.DATA_DIR || './data', 'relationshipos.store.json'));
fs.rmSync(file, { force: true });
console.log(`Reset store: ${file}`);
