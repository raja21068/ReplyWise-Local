const axios = require('axios');
const { filterOptions } = require('../safety/guardrails');

async function generateSuggestionsOllama({ contact, recentMessages, incomingMessage, userPersona }) {
  const baseUrl = process.env.OLLAMA_BASE_URL || 'http://localhost:11434';
  const model = process.env.OLLAMA_MODEL || 'llama3.1';
  const prompt = buildSuggestionPrompt({ contact, recentMessages, incomingMessage, userPersona });
  const response = await axios.post(`${baseUrl}/api/generate`, {
    model,
    prompt,
    stream: false,
    format: 'json'
  }, { timeout: 120000 });
  const raw = response.data && response.data.response ? response.data.response : '{}';
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    parsed = { options: [] };
  }
  parsed.options = filterOptions(parsed.options || []);
  parsed.stage_analysis = parsed.stage_analysis || contact.conversation_stage || 'unknown';
  parsed.next_move_hint = parsed.next_move_hint || 'Match energy and keep manual control.';
  parsed.provider = 'ollama';
  return parsed;
}

async function summarizeProfileOllama({ contact, messages }) {
  const baseUrl = process.env.OLLAMA_BASE_URL || 'http://localhost:11434';
  const model = process.env.OLLAMA_MODEL || 'llama3.1';
  const chat = messages.map((m) => `${m.direction}: ${m.body}`).join('\n');
  const prompt = `You are analyzing a chat history to refresh a concise contact memory. Return strict JSON only.
Fields: summary, preferredLanguage, emojiStyle, conversationStage.
Allowed preferredLanguage: english, roman-urdu, mixed.
Allowed emojiStyle: none, light, heavy.
Allowed conversationStage: initial, early_rapport, building_rapport, flirty, deepening, paused, repair_needed.
Keep summary respectful and factual. Do not invent sensitive facts.

CONTACT: ${contact.display_name || contact.whatsapp_id}
CHAT:
${chat}`;

  const response = await axios.post(`${baseUrl}/api/generate`, {
    model,
    prompt,
    stream: false,
    format: 'json'
  }, { timeout: 120000 });
  const raw = response.data && response.data.response ? response.data.response : '{}';
  try {
    const parsed = JSON.parse(raw);
    return {
      summary: parsed.summary || 'Not enough information yet.',
      preferredLanguage: parsed.preferredLanguage || 'mixed',
      emojiStyle: parsed.emojiStyle || 'light',
      conversationStage: parsed.conversationStage || 'initial'
    };
  } catch (err) {
    return {
      summary: 'Profile refresh failed to parse cleanly. Keep using manual notes and local defaults.',
      preferredLanguage: 'mixed',
      emojiStyle: 'light',
      conversationStage: 'initial'
    };
  }
}

function buildSuggestionPrompt({ contact, recentMessages, incomingMessage, userPersona }) {
  const chat = recentMessages.map((m) => `${m.direction}: ${m.body}`).join('\n');
  return `You are RelationshipOS, a human-in-the-loop reply drafting assistant.
The user must approve every message. Generate respectful suggestions only.
Do not pressure, guilt-trip, manipulate, sexualize, or fabricate personal facts.
Match the user's natural tone and the contact's language style.

CONTACT PROFILE:
${contact.profile_summary || 'No profile yet.'}

RECENT CHAT:
${chat}

LATEST MESSAGE:
${incomingMessage.body}

USER PERSONA:
${userPersona}

Return strict JSON:
{
  "options": [
    {"tone":"playful", "text":"...", "rationale":"...", "score":85, "risk":"low"},
    {"tone":"warm", "text":"...", "rationale":"...", "score":80, "risk":"low"},
    {"tone":"genuine/casual", "text":"...", "rationale":"...", "score":78, "risk":"low"}
  ],
  "stage_analysis":"...",
  "next_move_hint":"..."
}`;
}

module.exports = {
  generateSuggestionsOllama,
  summarizeProfileOllama
};
