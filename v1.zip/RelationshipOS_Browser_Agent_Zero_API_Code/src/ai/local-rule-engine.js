const { filterOptions } = require('../safety/guardrails');

function detectLanguage(text) {
  const romanUrduHints = ['kya', 'haan', 'nahi', 'acha', 'thora', 'kaisa', 'batao', 'hai', 'tha', 'tum'];
  const lower = String(text || '').toLowerCase();
  const hits = romanUrduHints.filter((w) => lower.includes(w)).length;
  if (hits >= 2) return 'mixed';
  return 'english';
}

function generateSuggestionsLocal({ contact, recentMessages, incomingMessage, userPersona }) {
  const body = incomingMessage.body || '';
  const lower = body.toLowerCase();
  const language = contact.preferred_language || detectLanguage(body);
  const emoji = contact.emoji_style === 'none' ? '' : contact.emoji_style === 'heavy' ? ' 😂' : ' 😄';

  let options;

  if (lower.includes('weekend') || lower.includes('plan')) {
    options = language === 'english'
      ? [
          { tone: 'playful', text: `No grand plan yet, maybe food and a little peace${emoji} What about you?`, rationale: 'Light, easy, and invites her to share.', score: 86, risk: 'low' },
          { tone: 'warm/flirty', text: `Nothing fixed yet. If the company is good, even a simple plan works${emoji}`, rationale: 'Soft flirt without pressure.', score: 78, risk: 'medium' },
          { tone: 'genuine/casual', text: `Haven't decided yet. Any good ideas?`, rationale: 'Simple and keeps the conversation moving.', score: 82, risk: 'low' }
        ]
      : [
          { tone: 'playful', text: `Abhi tak koi solid plan nahi, shayad food aur rest${emoji} Tumhara kya scene hai?`, rationale: 'Natural Roman Urdu mix with playful energy.', score: 88, risk: 'low' },
          { tone: 'warm/flirty', text: `Plan toh abhi nahi bana, lekin achi company mil jaye toh weekend set hai${emoji}`, rationale: 'Warm but not pushy.', score: 80, risk: 'medium' },
          { tone: 'genuine/casual', text: `Honestly abhi decide nahi kiya. Tum suggest karo koi acha plan?`, rationale: 'Genuine and invites her input.', score: 84, risk: 'low' }
        ];
  } else if (lower.includes('tired') || lower.includes('sad') || lower.includes('stress') || lower.includes('exam')) {
    options = language === 'english'
      ? [
          { tone: 'empathetic', text: `That sounds exhausting. Take it easy for a bit, you don't have to handle everything at once.`, rationale: 'Matches emotional context with support.', score: 92, risk: 'low' },
          { tone: 'gentle/playful', text: `Exam stress is a villain honestly. Small chai break first, then world domination.`, rationale: 'Lightens the mood respectfully.', score: 84, risk: 'low' },
          { tone: 'caring', text: `I get why you're drained. Want to vent or should I distract you?`, rationale: 'Gives her control over the next direction.', score: 90, risk: 'low' }
        ]
      : [
          { tone: 'empathetic', text: `Yaar ye kaafi exhausting lag raha hai. Thora sa break lo, sab kuch ek sath handle karna zaroori nahi.`, rationale: 'Supportive Roman Urdu response.', score: 92, risk: 'low' },
          { tone: 'gentle/playful', text: `Exam stress literally villain hai. Pehle chai break, phir comeback${emoji}`, rationale: 'Supportive but light.', score: 85, risk: 'low' },
          { tone: 'caring', text: `Samajh sakta hoon. Vent karna hai ya mood distract karun?`, rationale: 'Lets her choose emotional support or distraction.', score: 90, risk: 'low' }
        ];
  } else if (lower.includes('?')) {
    options = language === 'english'
      ? [
          { tone: 'casual', text: `Good question. I think it depends, but I'd say yes mostly${emoji}`, rationale: 'Answers lightly and leaves room for follow-up.', score: 75, risk: 'low' },
          { tone: 'playful', text: `I have a proper answer and a dramatic answer. Which one do you want first?`, rationale: 'Creates playful curiosity.', score: 82, risk: 'low' },
          { tone: 'genuine', text: `Honestly, I'd say it depends on the situation. What made you ask?`, rationale: 'Adds genuine curiosity.', score: 84, risk: 'low' }
        ]
      : [
          { tone: 'casual', text: `Good question. Mere khayal se situation pe depend karta hai${emoji}`, rationale: 'Natural mixed reply.', score: 76, risk: 'low' },
          { tone: 'playful', text: `Iska ek seedha answer hai aur ek dramatic answer. Pehle konsa sunna hai?`, rationale: 'Playful and engaging.', score: 84, risk: 'low' },
          { tone: 'genuine', text: `Honestly situation pe depend karta hai. Tumne kyun poocha?`, rationale: 'Keeps conversation meaningful.', score: 84, risk: 'low' }
        ];
  } else {
    options = language === 'english'
      ? [
          { tone: 'casual', text: `Haha fair${emoji}`, rationale: 'Short human reply for low-context messages.', score: 76, risk: 'low' },
          { tone: 'curious', text: `Tell me more, I feel there's a story here.`, rationale: 'Opens the conversation without pressure.', score: 80, risk: 'low' },
          { tone: 'warm', text: `I get you. That actually makes sense.`, rationale: 'Validates her message naturally.', score: 78, risk: 'low' }
        ]
      : [
          { tone: 'casual', text: `Hahaha fair${emoji}`, rationale: 'Short natural reply.', score: 76, risk: 'low' },
          { tone: 'curious', text: `Iske peechay story lag rahi hai, batao zara.`, rationale: 'Encourages her to elaborate.', score: 80, risk: 'low' },
          { tone: 'warm', text: `Samajh gaya, honestly makes sense.`, rationale: 'Warm validation.', score: 78, risk: 'low' }
        ];
  }

  return {
    options: filterOptions(options),
    stage_analysis: inferStage(recentMessages),
    next_move_hint: 'Watch whether the next reply is warmer, shorter, or asks a question back. Match energy instead of over-pursuing.',
    provider: 'local-rule-engine',
    user_persona_used: userPersona
  };
}

function inferStage(messages) {
  const count = messages ? messages.length : 0;
  const joined = (messages || []).map((m) => m.body).join(' ').toLowerCase();
  if (joined.includes('date') || joined.includes('call') || joined.includes('meet')) return 'possible_move_to_call_or_meet';
  if (count > 30) return 'building_rapport';
  if (count > 10) return 'early_rapport';
  return 'initial';
}

function summarizeProfileLocal({ contact, messages }) {
  const allText = (messages || []).map((m) => m.body).join(' ').toLowerCase();
  const preferredLanguage = detectLanguage(allText);
  const emojiCount = (allText.match(/[😂😄😭🔥🙂😉]/g) || []).length;
  const emojiStyle = emojiCount > 8 ? 'heavy' : emojiCount > 0 ? 'light' : 'none';
  const conversationStage = messages.length > 60 ? 'building_rapport' : messages.length > 20 ? 'early_rapport' : 'initial';
  const summary = [
    `${contact.display_name || contact.external_contact_id || contact.whatsapp_id} (${contact.channel || 'whatsapp'}) profile summary.`,
    `Communication style appears ${preferredLanguage}, emoji usage ${emojiStyle}. Channel: ${contact.channel || 'whatsapp'}.`,
    `Conversation stage: ${conversationStage}.`,
    `Observed topics: ${extractTopics(allText).join(', ') || 'not enough signal yet'}.`,
    `Best reply style: respectful, natural, not too long, match the other person's energy.`,
    `Notes: This is a local generated summary; refine manually as needed.`
  ].join(' ');

  return { summary, preferredLanguage, emojiStyle, conversationStage };
}

function extractTopics(text) {
  const topics = [];
  if (text.includes('exam') || text.includes('study')) topics.push('studies/exams');
  if (text.includes('food') || text.includes('biryani') || text.includes('chai')) topics.push('food/chai');
  if (text.includes('weekend') || text.includes('plan')) topics.push('plans/weekend');
  if (text.includes('travel')) topics.push('travel');
  if (text.includes('cricket')) topics.push('cricket');
  return topics;
}

module.exports = {
  generateSuggestionsLocal,
  summarizeProfileLocal
};
