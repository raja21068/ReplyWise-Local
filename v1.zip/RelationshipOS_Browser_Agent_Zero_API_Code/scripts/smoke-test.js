const base = process.env.APP_BASE_URL || 'http://localhost:3000';

async function main() {
  const incoming = {
    externalContactId: 'tg_smoke_test',
    displayName: 'Smoke Test Contact',
    body: "So what's your weekend plan?",
  };
  const res = await fetch(`${base}/api/sandbox/telegram/incoming`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', accept: 'application/json' },
    body: JSON.stringify(incoming),
  });
  if (!res.ok) throw new Error(`incoming failed: ${res.status} ${await res.text()}`);
  const data = await res.json();
  if (!data.suggestionId) throw new Error('missing suggestionId');
  console.log('✓ incoming → suggestion:', data.suggestionId);

  const root = await fetch(`${base}/`);
  if (!root.ok) throw new Error(`dashboard failed: ${root.status}`);
  console.log('✓ dashboard reachable');
}

main().catch((err) => {
  console.error('Smoke test failed:', err);
  process.exit(1);
});
